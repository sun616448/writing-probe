// ── Thinking Probe personal config ──────────────────────────────────────────
// Fill in WORKER_URL and PROBE_SECRET after you deploy the Cloudflare Worker.
// This file is gitignored — never commit it.

// Your Cloudflare Worker URL — e.g. 'https://thinking-probe.yourname.workers.dev'
const WORKER_URL = 'https://writing-probe.sun616448.workers.dev';

// Must match the PROBE_SECRET secret you set in the Cloudflare dashboard.
// Pick any random string, e.g. 'xK9mP2qL8nR4tY7w'
const PROBE_SECRET = 'xK9mP2qL8nR4';

// Max API calls per calendar month.
// Each probe scan = 1 call; each "Submit" for an edit suggestion = 1 call.
// Rough cost at default settings: ~$0.01–$0.05 per call.
// 200 calls ≈ $2–$10/month depending on document length.
const MONTHLY_CALL_LIMIT = 200;
